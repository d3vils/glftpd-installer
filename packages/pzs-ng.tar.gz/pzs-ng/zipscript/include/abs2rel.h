#ifndef ABS2REL_H
#define ABS2REL_H

extern char *abs2rel(const char *, const char *, char *, const size_t);

#endif
