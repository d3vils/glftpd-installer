#ifndef DATACLEANER_H
#define DATACLEANER_H

void remove_dir_loop(char *);
void check_dir_loop(char *, int);

#endif

