#ifndef _COMPLETE_H_
#define _COMPLETE_H_

/*void complete(struct LOCATIONS *, struct VARS *, struct USERINFO **, struct GROUPINFO **, int);*/
/*extern void writetop(struct VARS *, struct USERINFO **, struct GROUPINFO **, int);*/
extern void complete(GLOBAL *, int);
extern void writetop(GLOBAL *, int);
#endif
