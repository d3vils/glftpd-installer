#ifndef POSTDEL_H
#define POSTDEL_H

#include "objects.h"

/* COMMENT THESE */
void writelog(GLOBAL *, char *, char *);
unsigned char get_filetype_postdel(GLOBAL *, char *);

#endif
